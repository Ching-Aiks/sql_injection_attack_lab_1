package com.ias101.lab1.model;

public record User(String username, String password) {
}
